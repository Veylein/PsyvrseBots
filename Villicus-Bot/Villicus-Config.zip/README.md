Villicus-Config — Local static control panel

Quick notes to make the static control panel and GitHub Pages demo work with a running backend.

- Purpose: These pages call your FastAPI backend (Villicus Website) to perform live actions on a selected guild (lazy setup, add staff role, export settings, audit logs).
- Requirement: The FastAPI backend must be publicly reachable (HTTPS) so GitHub Pages or any static site can call it and the OAuth redirect can complete.

Steps to enable sign-in and live control:

1) Deploy backend
   - Use the included Dockerfiles and `docker-compose.yml` to run locally, or deploy to Render/Railway/Cloud Run.
   - Required env vars: `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`, `DISCORD_TOKEN` (bot), `BOT_API_KEY`, `SESSION_SECRET`.
   - Optional but recommended: `REDIS_URL` and `ALLOWED_ORIGINS` (comma-separated origins allowed to call the API).

2) Set Discord Redirect URI
   - In the Discord Developer Portal, set the OAuth redirect URI to `https://<your-backend>/callback`.

3) Configure the static panel (this folder)
   - Open `index.html` in a browser or host this folder on GitHub Pages.
   - In the UI, set the Backend URL input to `https://<your-backend>` and hit Save (stored in `localStorage`).

4) Sign-in flow from GH Pages
   - The static UI will redirect users to `https://<your-backend>/login?return_to=...` for OAuth.
   - The backend performs the OAuth code exchange and sets a `villicus_session` cookie for the backend domain, plus a `villicus_csrf` cookie used for mutating requests.
   - Because cookies are set for the backend domain, the static site must make cross-origin requests with credentials; ensure `ALLOWED_ORIGINS` contains your GH Pages origin and the backend runs with CORS allow-credentials enabled (the default main.py supports this via `ALLOWED_ORIGINS`).

5) Usage
   - Select a guild ID in the UI (the bot must be in that guild and you must have permissions).
   - Use the control buttons to run lazy setup, add staff roles, export settings, and view audit logs.

Notes and troubleshooting
   - GitHub Pages alone cannot securely complete the OAuth code exchange; a backend is required.
   - If buttons return CORS or cookie errors, verify `ALLOWED_ORIGINS` includes the page origin and the backend is HTTPS.
   - For production, use a real database (Postgres), strong `SESSION_SECRET`, and set `REDIS_URL` for sessions.

If you want, I can patch the static demo pages to point to a specific backend domain you provide.

Demo mode
--
If you don't have a backend deployed right now, enable "Demo mode" in the control panel to simulate a fully-working premium UI that performs live-looking actions locally.

- Demo mode stores fake audit logs and settings per-guild in `localStorage` (keys prefixed with `villicus_demo_`).
- Actions (lazy setup, add staff, set warns, export) will succeed and create entries in the local audit log so the UI behaves like a real control panel.
- When you're ready to connect to a real backend, clear demo mode and set the Backend URL input to `https://<your-backend>`.
