// Villicus-Config demo client
(function(){
  const $ = (sel)=>document.querySelector(sel);
  const backendInput = $('#backend-url');
  const guildInput = $('#guild-id');
  const demoCheckbox = $('#demo-mode');
  const debug = $('#debug');
  const auditEl = $('#audit-log');

  // default base - will use same origin when empty
  function getBase(){
    const v = backendInput.value.trim();
    if (!v) return '';
    return v.replace(/\/+$/,'');
  }

  function isDemo(){
    return demoCheckbox && demoCheckbox.checked;
  }

  function toast(msg){
    // render toast UI with icon, dismiss and stacking
    try{
      let container = document.querySelector('.toast-container');
      if (!container){ container = document.createElement('div'); container.className = 'toast-container'; document.body.appendChild(container); }
      const t = document.createElement('div'); t.className = 'toast success';
      t.setAttribute('role','status');
      t.innerHTML = `
        <span class="icon">${iconSVG('success')}</span>
        <div class="body"><strong>${escapeHtml(String(msg))}</strong></div>
        <button class="dismiss" aria-label="Dismiss">×</button>
      `;
      // add entry and focus for accessibility
      container.prepend(t);
      // entrance micro animation
      requestAnimationFrame(()=> t.classList.add('pulse'));
      // dismiss on click
      t.querySelector('.dismiss').addEventListener('click', ()=> removeToast(t));
      t.addEventListener('click', ()=> removeToast(t));
      // auto remove
      const ttl = 4200;
      const to = setTimeout(()=> removeToast(t), ttl);
      t._timeout = to;
      function removeToast(node){
        if (!node) return;
        node.style.opacity = '0'; node.style.transform='translateY(8px) scale(.98)';
        clearTimeout(node._timeout);
        setTimeout(()=> node.remove(), 260);
      }
    }catch(e){ console.log('toast error', e); }
    // also write to debug pane for visibility
    try{ debug.textContent = msg + '\n' + debug.textContent; }catch(e){}
  }

  // helpers for safe HTML in toasts
  function escapeHtml(s){ return s.replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }

  function iconSVG(type){
    if (type==='success') return `<svg class="svg-pop" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 6L9 17l-5-5" stroke="#042014" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    if (type==='info') return `<svg class="svg-pop" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="9" stroke="#022032" stroke-width="2"/><path d="M12 8v.01M11 12h1v4h1" stroke="#022032" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    return `<svg class="svg-pop" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18 6L6 18M6 6l12 12" stroke="#2b0500" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  }

  // read CSRF cookie if present
  function getCookie(name){
    const m = document.cookie.match('(?:^|;)\\s*'+name+'=([^;]*)');
    return m? decodeURIComponent(m[1]) : null;
  }

  async function apiFetch(path, opts={}){
    // Demo mode: simulate responses locally
    if (isDemo()){
      await new Promise(r=>setTimeout(r, 250));
      // simulate a few endpoints used by the UI
      if (path.startsWith('/guild_logs') || path.startsWith('/configure/') && path.endsWith('/logs')){
        const gid = path.split('/').pop() || localStorage.getItem('villicus_guild');
        const logs = JSON.parse(localStorage.getItem('villicus_demo_logs_'+gid) || '[]');
        return {ok:true,status:200,json:{logs}};
      }
      if (path.endsWith('/lazy_setup')){
        const gid = path.split('/').slice(-2, -1)[0] || localStorage.getItem('villicus_guild');
        const logs = JSON.parse(localStorage.getItem('villicus_demo_logs_'+gid) || '[]');
        logs.unshift({action:'lazy_setup', moderator_id:'demo', target_id:gid, reason:'Demo lazy setup', ts:Date.now()});
        localStorage.setItem('villicus_demo_logs_'+gid, JSON.stringify(logs));
        return {ok:true,status:200,json:{message:'queued'}};
      }
      if (path.endsWith('/export')){
        const gid = path.split('/').slice(-2, -1)[0] || localStorage.getItem('villicus_guild');
        const settings = JSON.parse(localStorage.getItem('villicus_demo_settings_'+gid) || '{}');
        return {ok:true,status:200,json:{settings}};
      }
      if (path.endsWith('/add_staff')){
        const body = opts.body ? JSON.parse(opts.body) : {};
        const gid = path.split('/').slice(-2, -1)[0] || localStorage.getItem('villicus_guild');
        const settings = JSON.parse(localStorage.getItem('villicus_demo_settings_'+gid) || '{}');
        settings.staff = settings.staff||[]; settings.staff.push({role_id: body.role_id, level: body.level});
        localStorage.setItem('villicus_demo_settings_'+gid, JSON.stringify(settings));
        const logs = JSON.parse(localStorage.getItem('villicus_demo_logs_'+gid) || '[]');
        logs.unshift({action:'add_staff', moderator_id:'demo', target_id:body.role_id, reason:'Demo add role', ts:Date.now()});
        localStorage.setItem('villicus_demo_logs_'+gid, JSON.stringify(logs));
        return {ok:true,status:200,json:{ok:true}};
      }
      if (path.endsWith('/set_warns')){
        const body = opts.body ? JSON.parse(opts.body) : {};
        const gid = path.split('/').slice(-2, -1)[0] || localStorage.getItem('villicus_guild');
        const settings = JSON.parse(localStorage.getItem('villicus_demo_settings_'+gid) || '{}');
        settings.warns = {count: body.warns, action: body.action};
        localStorage.setItem('villicus_demo_settings_'+gid, JSON.stringify(settings));
        const logs = JSON.parse(localStorage.getItem('villicus_demo_logs_'+gid) || '[]');
        logs.unshift({action:'set_warns', moderator_id:'demo', target_id:gid, reason:`warns=${body.warns}`, ts:Date.now()});
        localStorage.setItem('villicus_demo_logs_'+gid, JSON.stringify(logs));
        return {ok:true,status:200,json:{ok:true}};
      }
      // default demo response
      return {ok:true,status:200,json:{message:'demo ok'}};
    }

    const base = getBase();
    const url = base ? base + path : path;
    opts.credentials = opts.credentials || 'include';
    opts.headers = opts.headers || {};
    // attach CSRF header when available
    const csrf = getCookie('villicus_csrf');
    if (csrf && !opts.headers['X-CSRF-Token']) opts.headers['X-CSRF-Token'] = csrf;
    const res = await fetch(url, opts);
    let j = null;
    try{ j = await res.json(); }catch(e){}
    return {ok: res.ok, status: res.status, json: j, raw: res};
  }

  $('#set-guild').addEventListener('click', (e)=>{
    const gid = guildInput.value.trim();
    if (!gid) return toast('Enter guild id');
    localStorage.setItem('villicus_guild', gid);
    toast('Selected guild ' + gid);
    loadGuild(gid);
  });

  async function loadGuild(gid){
    try{
      const r = await apiFetch(`/configure/${gid}`);
      // note: this endpoint returns HTML in real backend; we instead fetch settings via /api/token->/api/guilds settings path when available
      // attempt to fetch settings directly
      const tResp = await apiFetch('/api/token', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({access_token: null, guild_id: gid})});
      // fallback: try settings proxy
      const settingsResp = await apiFetch(`/configure/${gid}`);
      toast('Loaded guild page (proxy).');
    }catch(e){ toast('Failed to load guild: '+e.message); }
    refreshAudit(gid);
  }

  async function refreshAudit(gid){
    if (!gid) gid = localStorage.getItem('villicus_guild');
    if (!gid) return toast('No guild selected');
    auditEl.innerHTML = 'Loading…';
    const r = await apiFetch(`/guild_logs/${gid}`);
    if (!r.ok){ auditEl.innerHTML = 'Failed to load logs'; return; }
    const logs = (r.json && r.json.logs) || [];
    auditEl.innerHTML = logs.map(l=>`<div class="entry"><strong>${l.action}</strong> — ${l.moderator_id || 'system'} → ${l.target_id || ''}<div class="muted small">${l.reason||''}</div></div>`).join('') || '<div class="muted">No logs</div>';
  }

  $('#btn-refresh-logs').addEventListener('click', ()=> refreshAudit());

  $('#btn-lazy').addEventListener('click', async ()=>{
    const gid = localStorage.getItem('villicus_guild');
    if (!gid) return toast('Select guild first');
    const r = await apiFetch(`/configure/${gid}/lazy_setup`, {method:'POST'});
    toast(r.ok? 'Lazy setup queued' : 'Failed: '+(r.json?.error || r.status));
    refreshAudit(gid);
  });

  $('#btn-export').addEventListener('click', async ()=>{
    const gid = localStorage.getItem('villicus_guild');
    if (!gid) return toast('Select guild first');
    const r = await apiFetch(`/configure/${gid}/export`);
    if (!r.ok) return toast('Export failed');
    const blob = new Blob([JSON.stringify(r.json.settings||{},null,2)], {type:'application/json'});
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `guild_${gid}_settings.json`; a.click();
    toast('Exported settings');
  });

  $('#btn-add-role').addEventListener('click', async ()=>{
    const gid = localStorage.getItem('villicus_guild');
    if (!gid) return toast('Select guild first');
    const role = $('#staff-role').value.trim();
    const level = $('#staff-level').value;
    if (!role) return toast('Enter role id');
    const r = await apiFetch(`/configure/${gid}/add_staff`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({role_id: role, level})});
    toast(r.ok? 'Role added' : 'Failed to add role');
  });

  $('#btn-set-warns').addEventListener('click', async ()=>{
    const gid = localStorage.getItem('villicus_guild');
    if (!gid) return toast('Select guild first');
    const warns = Number($('#warns-count').value||0);
    const action = $('#warn-action-select').value;
    const r = await apiFetch(`/configure/${gid}/set_warns`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({warns, action})});
    toast(r.ok? 'Warns updated' : 'Failed to update warns');
  });

  // init
  (function(){
    const g = localStorage.getItem('villicus_guild'); if (g) guildInput.value = g;
    const b = localStorage.getItem('villicus_backend'); if (b) backendInput.value = b;
    backendInput.addEventListener('change', ()=> localStorage.setItem('villicus_backend', backendInput.value.trim()));
    if (demoCheckbox){
      const d = localStorage.getItem('villicus_demo');
      demoCheckbox.checked = d === '1';
      demoCheckbox.addEventListener('change', ()=> localStorage.setItem('villicus_demo', demoCheckbox.checked ? '1' : '0'));
    }
    const sign = $('#btn-signin'); if (sign) sign.addEventListener('click', ()=>{
      if (isDemo()){
        toast('Signed in (demo)');
        // create a fake session marker
        localStorage.setItem('villicus_demo_signed_in','1');
      } else {
        const base = getBase() || '';
        const dest = base + '/login?return_to=' + encodeURIComponent(location.href);
        window.location.href = dest;
      }
    });
    if (g) loadGuild(g);
  })();

  // --- Dashboard and server-page integration ---
  // Populate a demo servers list for dashboard.html
  function ensureDemoServers(){
    if (localStorage.getItem('villicus_demo_servers')) return JSON.parse(localStorage.getItem('villicus_demo_servers'));
    const seeds = [
      {id:'111111111111111111',name:'Neon Knights',icon:null,desc:'Mod team: 12'},
      {id:'222222222222222222',name:'Arcadia',icon:null,desc:'Small community'},
      {id:'333333333333333333',name:'VeyLein Test',icon:null,desc:'Demo server'},
    ];
    localStorage.setItem('villicus_demo_servers', JSON.stringify(seeds));
    // seed richer fake audit logs for each server
    seeds.forEach(s=>{
      const key = 'villicus_demo_logs_'+s.id;
      if (!localStorage.getItem(key)){
        const base = [
          {action:'bot_added', moderator_id:'system', target_id:s.id, reason:'Villicus joined', ts: Date.now() - 1000*60*60*24*5},
          {action:'welcome_set', moderator_id:randomName(), target_id:'#general', reason:'Welcome message configured', ts: Date.now() - 1000*60*60*24*3},
          {action:'role_added', moderator_id:randomName(), target_id:'Role-1234', reason:'Staff role added', ts: Date.now() - 1000*60*60*24*1},
        ];
        localStorage.setItem(key, JSON.stringify(base));
      }
      const sKey = 'villicus_demo_settings_'+s.id;
      if (!localStorage.getItem(sKey)){
        const settings = {prefix:'!',staff:[{role_id:'Role-1234',level:5}],commands:[],warns:{count:3,action:'mute'}};
        localStorage.setItem(sKey, JSON.stringify(settings));
      }
    });
    return seeds;
  }

  function randomName(){
    const names = ['Astra','Riven','Kai','Lyra','Orin','Mira','Zen','Vex'];
    return names[Math.floor(Math.random()*names.length)]+Math.floor(Math.random()*99);
  }

  function renderDashboard(){
    const listEl = document.getElementById('server-cards');
    if (!listEl) return;
    const servers = ensureDemoServers();
    listEl.innerHTML = servers.map(s=>{
      return `<div class="card" role="button" tabindex="0" data-gid="${s.id}" aria-label="Open ${s.name}">
        <strong>${s.name}</strong>
        <div class="muted small">${s.desc||''}</div>
      </div>`
    }).join('');
    document.querySelectorAll('#server-cards .card').forEach(c=>{
      c.addEventListener('click', ()=> openServer(c.dataset.gid));
      c.addEventListener('keydown', (e)=>{ if (e.key==='Enter' || e.key===' ') openServer(c.dataset.gid); });
    });
    document.getElementById('stat-servers').textContent = servers.length;
  }

  function openServer(gid){
    localStorage.setItem('villicus_guild', gid);
    // navigate to server page
    if (location.pathname.endsWith('server.html')){
      // already on page — load
      loadServerPage(gid);
    } else {
      location.href = 'server.html';
    }
  }

  // When server.html loads, populate modules and load demo settings
  function loadServerPage(gid){
    gid = gid || localStorage.getItem('villicus_guild');
    if (!gid) return;
    const nameEl = document.getElementById('server-name'); if (nameEl) nameEl.textContent = `Server — ${gid}`;
    const descEl = document.getElementById('server-desc'); if (descEl) descEl.textContent = `Editing server ${gid} (demo)`;
    // load demo settings
    const settings = JSON.parse(localStorage.getItem('villicus_demo_settings_'+gid) || '{}');
    // commands
    const cmdList = document.getElementById('cmd-list'); if (cmdList){
      const cmds = settings.commands || [];
      cmdList.innerHTML = cmds.map(c=>`<div class="card"><strong>${c.name}</strong><div class="muted small">${c.response||''}</div></div>`).join('') || '<div class="muted">No commands</div>';
    }
    // prefix
    const prefixInput = document.getElementById('prefix-input'); if (prefixInput) prefixInput.value = settings.prefix || '!';
    // staff roles
    const staffRoles = document.getElementById('staff-roles'); if (staffRoles){
      const staff = settings.staff || [];
      staffRoles.innerHTML = staff.map(r=>`<div class="card"><strong>Role ${r.role_id}</strong><div class="muted small">Level ${r.level}</div></div>`).join('') || '<div class="muted">No staff roles</div>';
    }
  }

  // tabs and module interactions for server.html
  function bindServerUI(){
    const tabs = document.querySelectorAll('.subnav [role="tab"]');
    if (tabs.length){
      tabs.forEach(t=> t.addEventListener('click', ()=>{
        tabs.forEach(x=> x.setAttribute('aria-selected','false'));
        t.setAttribute('aria-selected','true');
        const tab = t.dataset.tab;
        document.querySelectorAll('.module').forEach(m=> m.classList.add('hidden'));
        const el = document.querySelector(`.module[data-module="${tab}"]`);
        if (el) el.classList.remove('hidden');
        el && el.querySelector('input,textarea,button') && el.querySelector('input,textarea,button').focus();
      }));
      // keyboard nav
      tabs.forEach(t=> t.addEventListener('keydown', (e)=>{
        let idx = Array.from(tabs).indexOf(t);
        if (e.key==='ArrowDown') { idx = Math.min(tabs.length-1, idx+1); tabs[idx].focus(); }
        if (e.key==='ArrowUp') { idx = Math.max(0, idx-1); tabs[idx].focus(); }
      }));
    }

    // add command handler
    const form = document.getElementById('form-commands');
    if (form){
      form.addEventListener('submit', (ev)=>{
        ev.preventDefault();
        const gid = localStorage.getItem('villicus_guild');
        const name = document.getElementById('cmd-name').value.trim();
        const resp = document.getElementById('cmd-response').value.trim();
        if (!name){ toast('Command name required'); return; }
        if (isDemo()){
          const key = 'villicus_demo_settings_'+gid;
          const settings = JSON.parse(localStorage.getItem(key) || '{}');
          settings.commands = settings.commands||[]; settings.commands.push({name, response:resp});
          localStorage.setItem(key, JSON.stringify(settings));
          loadServerPage(gid);
          toast('Command added (demo)');
          form.reset();
        } else {
          // call backend to add command (placeholder)
          apiFetch(`/configure/${gid}/add_command`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({name, response:resp})}).then(r=>{
            toast(r.ok? 'Command added' : 'Failed to add');
            loadServerPage(gid);
          });
        }
      });
    }

    const saveBtn = document.getElementById('btn-save'); if (saveBtn) saveBtn.addEventListener('click', ()=>{
      const gid = localStorage.getItem('villicus_guild');
      if (!gid) return toast('No server selected');
      const settings = JSON.parse(localStorage.getItem('villicus_demo_settings_'+gid) || '{}');
      settings.prefix = document.getElementById('prefix-input')?.value || settings.prefix || '!';
      localStorage.setItem('villicus_demo_settings_'+gid, JSON.stringify(settings));
      toast('Saved (demo)');
    });
  }

  // bootstrap page-specific behaviors
  document.addEventListener('DOMContentLoaded', ()=>{
    // dashboard
    if (location.pathname.endsWith('dashboard.html') || location.pathname.endsWith('/')) renderDashboard();
    // server
    if (location.pathname.endsWith('server.html')){
      const gid = localStorage.getItem('villicus_guild');
      if (!gid){
        // pick first demo server
        const servers = ensureDemoServers();
        if (servers && servers[0]) localStorage.setItem('villicus_guild', servers[0].id);
      }
      loadServerPage(localStorage.getItem('villicus_guild'));
      bindServerUI();
    }
  });

})();
